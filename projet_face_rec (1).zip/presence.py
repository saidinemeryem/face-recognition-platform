from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def affiche():
	mydb = mysql.connector.connect(
          host= "localhost", 
          username= "root", 
          password="", 
          database="utilisateurs"
          )
	mycursor= mydb.cursor()
	if request.method == 'POST':
	   mycursor.execute("select * from presence")
	   res = mycursor.fetchall()
	   mydb.commit()
	   mycursor.close()
	return render_template("tableau.html", presence = res)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port='5003', debug=True)